#include <iostream>
#include <string>
using namespace std;
string nome;
main () {
	cout<<"\n Infome uma string: ";
	getline(cin,nome);
	cout<<"\n\n Foi informado: "<<nome;
}