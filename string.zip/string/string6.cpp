#include <iostream>
#include <string>
using namespace std;
char nome1[]="Claudia";
char nome2[]=" Werlich";

main () {
	system("chcp 65001");
	cout<<" \n\n"<<strcat(nome1,nome2);
}