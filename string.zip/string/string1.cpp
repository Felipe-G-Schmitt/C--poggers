#include <iostream>
#include <string>
using namespace std;
main() {
	char nome[5]={ 'J', 'o', 'h', 'n', '\0'};
	string nome2 = ("deic");
	
	cout<<"O vetor da string: ";
	cout<<nome<<"\n";
	cout<<nome2<<"\n";
}